# Netlify deployment

This package is the deployable Astro/Starlight **site source**. It contains no Docker, Nginx, or server stack.

## Recommended: deploy from GitHub

1. Commit this folder to a GitHub repository.
2. In Netlify, choose **Add new project** → **Import an existing project**.
3. Select the repository and deploy.

Netlify reads these settings from `netlify.toml`:

```text
Build command: npm run build
Publish directory: dist
Node version: 22
```

No additional build settings are required.

## Domain

In Netlify, open **Domain management**, add:

```text
docs.forbidden-oasis.xyz
```

Then create the DNS record Netlify provides.

## Important

Do not upload this source ZIP to the Netlify drag-and-drop publisher. Drag-and-drop accepts an already-built `dist` directory. Import the repository so Netlify can install dependencies and run the Astro build.
