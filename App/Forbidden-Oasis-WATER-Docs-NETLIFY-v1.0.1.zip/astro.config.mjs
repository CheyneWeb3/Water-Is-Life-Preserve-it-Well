import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';

const publicRepo = 'https://github.com/CheyneWeb3/Water-Is-Life-Preserve-it-Well';
const siteUrl = process.env.SITE_URL || 'https://docs.forbidden-oasis.xyz';

export default defineConfig({
  site: siteUrl,
  output: 'static',
  integrations: [
    starlight({
      title: 'FORBIDDEN OASIS · WATER',
      description: 'Official project, staking protocol, dApp, contract and developer documentation for Forbidden Oasis WATER.',
      favicon: '/assets/water-drop.webp',
      social: [
        { icon: 'github', label: 'Public GitHub repository', href: publicRepo },
      ],
      customCss: ['./src/styles/oasis.css'],
      lastUpdated: true,
      credits: false,
      sidebar: [
        { label: 'Enter the Oasis', link: '/' },
        {
          label: 'Start Here',
          items: [
            { label: 'Quick Start', link: '/start/quick-start/' },
            { label: 'Wallet & BSC Mainnet', link: '/start/wallet-mainnet/' },
            { label: 'Your Personal Vault', link: '/start/personal-vault/' },
          ],
        },
        {
          label: 'Forbidden Oasis Project',
          items: [
            { label: 'Project Overview', link: '/project/overview/' },
            { label: 'WATER Token', link: '/project/water-token/' },
            { label: 'Tokenomics', link: '/project/tokenomics/' },
            { label: 'Roadmap & Ecosystem', link: '/project/roadmap/' },
          ],
        },
        {
          label: 'Staking Guide',
          items: [
            { label: 'Staking Overview', link: '/staking/overview/' },
            { label: 'Flexible Staking', link: '/staking/flexible/' },
            { label: 'Locked Staking', link: '/staking/locked/' },
            { label: 'Claim WATER', link: '/staking/claim-water/' },
            { label: 'Claim BNB', link: '/staking/claim-bnb/' },
            { label: 'Compound Rewards', link: '/staking/compound/' },
            { label: 'Withdraw & Re-lock', link: '/staking/withdraw-relock/' },
            { label: 'Locked Emergency Exit', link: '/staking/emergency-exit/' },
          ],
        },
        {
          label: 'Protocol',
          items: [
            { label: 'Architecture', link: '/protocol/architecture/' },
            { label: 'Dividend-Preserving Vaults', link: '/protocol/dividend-preserving-vaults/' },
            { label: 'Reward Pools & Accounting', link: '/protocol/reward-pools/' },
            { label: 'Locked Lifecycle', link: '/protocol/locked-lifecycle/' },
            { label: 'BNB → WATER Adapter', link: '/protocol/bnb-adapter/' },
            { label: 'Governance & Upgradeability', link: '/protocol/governance/' },
            { label: 'Safety & Mainnet Readiness', link: '/protocol/safety-readiness/' },
          ],
        },
        {
          label: 'dApp System',
          items: [
            { label: 'Dashboard', link: '/app/dashboard/' },
            { label: 'Vault Workspace', link: '/app/vault/' },
            { label: 'Activity & BscScan', link: '/app/activity/' },
            { label: 'Wallet / Reown AppKit', link: '/app/wallet-reown/' },
            { label: 'Admin System', link: '/app/admin/' },
            { label: 'Troubleshooting', link: '/app/troubleshooting/' },
          ],
        },
        {
          label: 'Contracts',
          items: [
            { label: 'Mainnet Deployments', link: '/contracts/mainnet/' },
            { label: 'Controller API', link: '/contracts/controller/' },
            { label: 'Lens & Vault APIs', link: '/contracts/lens-vault/' },
            { label: 'WATER Token API', link: '/contracts/token/' },
          ],
        },
        {
          label: 'Developers',
          items: [
            { label: 'Frontend Architecture', link: '/developers/frontend/' },
            { label: 'Integration Notes', link: '/developers/integration/' },
            { label: 'Run This Docs Site', link: '/developers/docs-site/' },
            { label: 'Public Repository', link: '/developers/public-repo/' },
          ],
        },
        {
          label: 'Reference',
          items: [
            { label: 'FAQ', link: '/reference/faq/' },
            { label: 'Glossary', link: '/reference/glossary/' },
            { label: 'Version & Scope', link: '/reference/version/' },
          ],
        },
        { label: 'Forbidden Oasis Website ↗', link: 'https://forbidden-oasis.xyz/' },
        { label: 'Public GitHub Repository ↗', link: publicRepo },
      ],
    }),
  ],
});
