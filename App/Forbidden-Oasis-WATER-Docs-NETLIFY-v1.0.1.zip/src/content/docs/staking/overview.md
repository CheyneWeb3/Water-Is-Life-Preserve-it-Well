---
title: Staking Overview
description: The current WATER Flexible and Locked staking model.
---

# Staking Overview

A single personal vault can hold **two independent staking positions at the same time**.

```text
PERSONAL WATER VAULT
│
├── FLEXIBLE
│   ├── separate principal
│   ├── separate reward accounting
│   └── normal withdrawal available
│
└── LOCKED
    ├── separate principal
    ├── separate reward accounting
    └── fixed 30-day lock
```

## Core rules

- New Locked staking never silently moves existing Flexible principal.
- Normal `withdraw()` uses Flexible principal only.
- Moving Flexible principal into Locked requires an explicit re-lock amount.
- WATER compounding requires an explicit destination pool.
- BNB compounding requires an approved adapter, minimum-output protection, deadline and explicit destination pool.
- Locked principal has its own expiry lifecycle.
