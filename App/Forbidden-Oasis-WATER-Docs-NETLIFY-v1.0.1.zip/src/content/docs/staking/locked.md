---
title: Locked Staking
description: The current fixed 30-day WATER Locked position.
---

# Locked Staking

The current Locked product uses a **fixed 30-day lock**. There are no 90/180/365-day multiplier tiers in the current V4.4.3 staking model.

Locked has its own funded reward pool and reward rate. Its reward advantage is created by how the Locked pool is funded and scheduled, not by a fake multiplier over Flexible.

## Adding fresh WATER to active Locked

When fresh wallet WATER is explicitly added to an active Locked position, the Locked expiry restarts for the resulting Locked position. Existing Flexible WATER remains untouched.

## At expiry

When the Locked period expires and the position is synchronized, expired Locked principal rolls into Flexible. The blockchain timestamp determines expiry.
