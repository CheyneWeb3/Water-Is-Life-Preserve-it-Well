---
title: Compound Rewards
description: Compound WATER rewards or convert vault BNB into WATER and restake it.
---

# Compound Rewards

## Compound WATER

Earned WATER can be compounded into either:

- **Flexible**, or
- the user's existing **Locked** position.

The destination is explicit. Existing Flexible principal is never silently moved to Locked.

## Compound BNB → WATER

Vault BNB can be converted into WATER through an approved adapter and then staked into the chosen destination pool.

The user supplies the BNB amount, approved adapter path, minimum WATER output and deadline. The current dApp refuses a zero slippage floor.

## Compound All

The dApp can guide WATER and BNB compounding together, but the current contract paths are separate, so the wallet can request up to two transactions.
