---
title: Claim WATER
description: Claim all or part of earned WATER without withdrawing principal.
---

# Claim WATER

Earned staking WATER can be claimed independently of principal.

The protocol keeps Flexible and Locked reward accounting separate, while the Lens exposes current claimable values for the frontend.

A partial claim is allowed: you can claim part of the available WATER and leave the remainder for a later claim or compound action.

Claiming WATER does not require withdrawing Flexible or Locked principal.
