---
title: Locked Emergency Exit
description: Voluntary early exit from the Locked WATER position and its consequences.
---

# Locked Emergency Exit

The voluntary Locked emergency exit is separate from normal Flexible withdrawal and separate from the protocol-level emergency shutdown system.

For the current staking design, a voluntary early Locked exit applies the Locked principal penalty and forfeits unclaimed Locked staking rewards for that position.

```text
Locked principal
├── 95% → user
└──  5% → tracked protocol penalty WATER
```

Available BNB belonging to the personal vault is returned under the exit path without being treated as the 5% WATER penalty. Flexible principal and Flexible reward accounting remain separate.

Because the action is intentionally destructive, the dApp requires an explicit confirmation flow before submission.
