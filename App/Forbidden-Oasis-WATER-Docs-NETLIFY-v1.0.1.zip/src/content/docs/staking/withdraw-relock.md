---
title: Withdraw & Re-lock
description: Withdraw Flexible principal or explicitly move selected Flexible WATER into Locked.
---

# Withdraw & Re-lock

## Withdraw Flexible

Normal withdrawal removes WATER from the Flexible position. It does not touch Locked principal.

## Re-lock

Re-lock is the explicit path for moving selected Flexible principal into Locked.

Example:

```text
Before
Flexible: 100,000 WATER
Locked:    50,000 WATER

Re-lock selected: 25,000 WATER

After
Flexible:  75,000 WATER
Locked:    75,000 WATER
```

Only the selected amount moves.
