---
title: Claim BNB
description: Pull eligible WATER token dividends into the personal vault and claim vault-held BNB.
---

# Claim BNB

BNB and WATER staking rewards are separate systems.

The user's personal vault is the on-chain holder of staked WATER. This allows the vault to participate in the WATER token's eligible dividend behavior.

## Two possible stages

1. **Pull Into Vault** — if token-level WATER dividends are still pending, the vault can pull them in.
2. **Claim BNB** — vault-held BNB is then sent to the vault owner.

The operator does not become the beneficiary of user BNB.
