---
title: Flexible Staking
description: WATER staking without a fixed lock.
---

# Flexible Staking

Flexible is the withdrawable side of WATER staking.

Flexible principal has its own balance and reward accounting and can coexist with a Locked position in the same personal vault.

## Stake flow

1. Connect on BSC Mainnet.
2. Create/reuse your personal vault.
3. Open **Stake WATER → Flexible**.
4. Enter the amount.
5. Approve WATER if required.
6. Submit the Flexible stake transaction.

## What Flexible does not do

Staking into Flexible does not change the user's Locked balance or Locked expiry. Withdrawing Flexible does not withdraw Locked principal.
