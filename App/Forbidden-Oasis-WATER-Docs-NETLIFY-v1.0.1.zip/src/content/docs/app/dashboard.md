---
title: Dashboard
description: Main user-facing WATER staking dashboard and pool status.
---

# dApp Dashboard

The dashboard is the main user-facing surface for WATER staking.

It presents:

- wallet connection and active network state;
- Flexible and Locked pool cards;
- pool totals and live reward-rate context;
- Mainnet readiness status;
- personal staking/vault summary;
- entry points into Stake WATER, My Vault, History and Docs; and
- links into selected transaction workspaces.

The production UI is width-driven and responsive while preserving the fixed visual character of the Forbidden Oasis staking panel.
