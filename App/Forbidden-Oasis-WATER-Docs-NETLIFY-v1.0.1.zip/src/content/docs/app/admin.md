---
title: Admin System
description: Operational and owner-facing controls exposed by the WATER staking dApp.
---

# Admin System

The dApp separates user staking from administrative operations.

## Staking administration

The admin workspace reads current Mainnet readiness, owner/operator addresses, feature flags, pause/emergency state, pool funding/schedules and contract addresses.

Controller-side operations include reward funding/scheduling, feature control, pause/unpause, synchronization/maintenance and governance-sensitive owner actions where the connected wallet has authority.

## WATER token-owner setup

The token-owner page covers token-side staking setup such as the WATER → staking-controller link and the token configuration/exemptions required for controller flows.

Admin UI access does not itself grant contract authority. Every privileged transaction is still enforced by the on-chain contract role checks.
