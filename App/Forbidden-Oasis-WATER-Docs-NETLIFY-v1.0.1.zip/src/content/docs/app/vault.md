---
title: Vault Workspace
description: User actions available inside the WATER personal-vault interface.
---

# Vault Workspace

The My Vault workspace routes each action into a dedicated transaction flow rather than one generic interaction panel.

## Actions

- Claim WATER
- Pull pending WATER dividends into the vault
- Claim BNB
- Compound WATER
- Compound BNB → WATER
- Compound All
- Withdraw Flexible
- Re-lock Flexible → Locked
- Voluntary Locked emergency exit

Each flow gives the user the amount inputs and state needed for that specific transaction, then surfaces wallet submission and BscScan transaction status.
