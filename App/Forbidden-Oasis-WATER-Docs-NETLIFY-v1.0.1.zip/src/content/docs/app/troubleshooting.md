---
title: Troubleshooting
description: Common reasons WATER staking actions are unavailable or fail.
---

# Troubleshooting

## A staking button is disabled

Common causes:

- wallet is disconnected;
- wallet is not on BSC Mainnet;
- amount is empty/invalid;
- WATER approval is still required;
- another transaction is pending;
- the selected protocol feature is disabled;
- staking is paused or under emergency shutdown; or
- Mainnet readiness has not passed.

## Mainnet says NOT READY

Use the readiness report to identify the failing condition. Do not redeploy simply because the UI reports a failure. Verify the underlying on-chain controller/token state first.

For reward reserve failures, compare controller WATER balance, `rewardReserveRequired()`, pool budgets and `rewardReserveSolvent()`.

## Claim BNB shows nothing

If token dividends are still pending rather than already held by the vault, use **Pull Into Vault** before Claim BNB.

## Compound BNB is unavailable

The deployment must have an approved BNB adapter configured, and the action requires non-zero minimum-output protection and a valid deadline.
