---
title: Wallet / Reown AppKit
description: Production wallet connection model for WATER staking.
---

# Wallet / Reown AppKit

The staking app uses **Reown AppKit 1.8.23** with the Wagmi adapter.

## Production network policy

The v3.5.6 production configuration exposes **BSC Mainnet only**:

```ts
import { bsc } from '@reown/appkit/networks'

export const networks = [bsc]
export const targetNetwork = bsc
```

The app's runtime supported-chain guard also accepts Chain 56 only. Testnet deployment data is retained in source for future development builds, but it is not exposed by the live production wallet network selector.
