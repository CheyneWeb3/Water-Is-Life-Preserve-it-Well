---
title: Activity & BscScan
description: Local dApp transaction activity and explorer links.
---

# Activity & BscScan

Transactions submitted through the dApp are recorded locally with action name, transaction hash, timestamp, chain and confirmation state.

The activity workspace links the connected wallet, personal vault, staking controller and submitted transactions to BscScan.

This browser-local activity history is designed for immediate usability. It is **not** a complete on-chain event index and should not be treated as one when reconstructing historical account activity.
