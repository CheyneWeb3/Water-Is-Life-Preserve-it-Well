---
title: WATER Token
description: WATER token role inside the Forbidden Oasis and staking systems.
---

# WATER Token

WATER is the asset used by the Forbidden Oasis project and the staking protocol.

## Role in staking

The staking controller does not hold user principal. Principal is held by each user's personal vault. The controller instead holds the funded WATER used for staking rewards and performs the accounting that determines reward liabilities.

## Mainnet token

| Item | Value |
| --- | --- |
| Network | BNB Smart Chain Mainnet |
| Chain ID | `56` |
| Symbol | `WATER` |
| Contract | [`0xE26505E856fB1Ee6Ad85D433E2Ac3C3516C676a5`](https://bscscan.com/address/0xE26505E856fB1Ee6Ad85D433E2Ac3C3516C676a5) |

The staking integration requires the token-side `stakingController` link and the required controller exemptions/configuration to be correct before Mainnet readiness passes.
