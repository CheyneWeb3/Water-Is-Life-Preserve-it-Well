---
title: Roadmap & Ecosystem
description: Project direction and the current implemented staking milestone.
---

# Roadmap & Ecosystem

The Forbidden Oasis public roadmap is organized around launch, project growth, listings, governance and broader ecosystem expansion.

From the staking side, the important implemented milestone is a production-grade modular staking stack with:

- permanent per-user vaults;
- independent Flexible and 30-day Locked positions;
- separately funded reward pools;
- WATER and BNB reward management;
- controlled BNB → WATER compounding;
- upgradeable controller and vault logic with stable user-facing addresses;
- owner/operator role separation; and
- a Mainnet-readiness gate in the production dApp.

The roadmap should be read as project direction, while the [Mainnet Deployments](/contracts/mainnet/) page documents the currently integrated staking contracts.
