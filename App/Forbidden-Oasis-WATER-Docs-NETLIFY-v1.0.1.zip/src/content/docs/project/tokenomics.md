---
title: Tokenomics
description: High-level WATER supply allocation and staking reserve model.
---

# Tokenomics

The public Forbidden Oasis site describes an original WATER supply of **100,000,000** and presents the project allocation as three major reservoirs:

| Allocation | Share | Purpose |
| --- | ---: | --- |
| Liquidity | 70% | Liquidity foundation for the WATER market |
| Staking fund | 20% | Funded WATER staking rewards |
| Nomad / project fund | 10% | Project operations and ecosystem growth |

The current staking deployment uses the 20 million WATER staking allocation as separately funded Flexible and Locked reward budgets.

## Reward funding is finite

Staking rewards are funded before emission. The controller tracks each pool's budget, active emission rate, accrued liabilities and remaining reserve. User deposits are not used as the source of staking rewards.

For current on-chain values, use the live controller and Lens reads instead of treating a documentation number as a real-time balance.
