---
title: Project Overview
description: Forbidden Oasis, WATER and the staking ecosystem.
---

# Forbidden Oasis Project

Forbidden Oasis is a BNB Chain project built around the **WATER** token, token-level BNB rewards, supply reduction mechanics and a separate funded staking system.

The public project site frames the ecosystem around long-term participation, the WATER supply and the staking reserve. The current staking system extends that project with independent Flexible and Locked positions inside permanent personal vaults.

## Core pieces

1. **WATER token** — the BNB Chain token with its own transfer, fee, burn, liquidity and dividend behavior.
2. **Dividend-preserving staking** — personal vaults keep staked WATER distributed across user-owned vault addresses rather than one custody address.
3. **Two funded reward pools** — Flexible and Locked staking have independent budgets and emission schedules.
4. **dApp** — a React/Vite application for users, vault management, activity and administrative operations.
5. **Public source** — project materials and the staking system are published in the public repository.

**Website:** https://forbidden-oasis.xyz/  
**Public repository:** https://github.com/CheyneWeb3/Water-Is-Life-Preserve-it-Well
