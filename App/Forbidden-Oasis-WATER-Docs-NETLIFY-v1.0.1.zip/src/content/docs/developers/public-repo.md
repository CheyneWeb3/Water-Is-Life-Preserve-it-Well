---
title: Public Repository
description: Public Forbidden Oasis WATER project source and documentation repository.
---

# Public Repository

The public Forbidden Oasis WATER project repository is:

**https://github.com/CheyneWeb3/Water-Is-Life-Preserve-it-Well**

Use the repository as the public source link for project documentation, staking-system explanations, app materials and testing resources that are intentionally published for the community.

This standalone docs site links back to the repository in the header, navigation and landing page.
