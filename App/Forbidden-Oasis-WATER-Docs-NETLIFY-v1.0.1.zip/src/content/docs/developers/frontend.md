---
title: Frontend Architecture
description: Current WATER staking dApp application stack and contract integration pattern.
---

# Frontend Architecture

The current staking application is a Vite + React + TypeScript dApp using:

- React 18
- Vite 6
- TypeScript
- MUI / Emotion
- Wagmi 3
- Viem 2
- TanStack Query
- Reown AppKit 1.8.23

## Integration pattern

Runtime contract selection comes from `src/config/contracts.ts`. The production app is Mainnet-only, while testnet deployment data is retained for future developer builds.

The staking read/write hook works with the stable controller proxy and routes detailed account/reward reads to the Lens. User BNB operations are routed to the account's personal vault.
