---
title: Run This Docs Site
description: Develop, build and deploy the standalone Forbidden Oasis Starlight documentation site on Netlify.
---

# Run This Docs Site

This documentation package is a standalone Astro + Starlight static site prepared for Netlify.

## Local development

```bash
npm install
npm run dev
```

Open the local URL shown by Astro.

## Production build

```bash
npm run build
npm run preview
```

The deployable static output is created in `dist/`.

## Deploy to Netlify

Push the project to GitHub, then import that repository into Netlify. The included `netlify.toml` supplies the complete build configuration:

```toml
[build]
  command = "npm run build"
  publish = "dist"
```

Netlify installs the dependencies, builds the documentation and publishes `dist/`. No Docker container or server is required.

## Custom domain

After the first deploy, add this domain in Netlify:

```text
https://docs.forbidden-oasis.xyz
```

Then create the DNS record specified by Netlify.
