---
title: Integration Notes
description: Rules developers must preserve when extending the WATER staking dApp.
---

# Integration Notes

When extending the staking UI, preserve these protocol rules:

1. **Controller proxy is the stable controller address.** Never direct normal frontend writes to the implementation address.
2. **Lens owns detailed read views.** `accountView()` and `earnedWater()` are Lens calls and take the controller address as an argument.
3. **Flexible and Locked are independent.** Never infer that adding to Locked means moving the entire Flexible balance.
4. **Normal withdrawal is Flexible-only.** Locked early exit is a distinct path.
5. **Compounding requires an explicit destination.** Do not silently choose Flexible or Locked for the user.
6. **BNB compound needs slippage/deadline protection.** Do not submit zero minimum output.
7. **Production is Mainnet-only.** Chain 97 data in source is development context, not a live network option.
8. **Do not turn RPC uncertainty into a false hard failure.** Readiness should distinguish missing data from an actually failed invariant.
