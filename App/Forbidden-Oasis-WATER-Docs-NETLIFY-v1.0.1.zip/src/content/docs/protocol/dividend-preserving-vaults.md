---
title: Dividend-Preserving Vaults
description: Why WATER staking keeps principal in personal user vaults.
---

# Dividend-Preserving Vaults

The controller deliberately does **not** custody user staking principal.

```text
STAKING CONTROLLER
├── reward reserves
├── reward accounting
├── pool schedules
├── lock synchronization
└── penalty accounting

USER VAULTS
├── User A principal
├── User B principal
├── User C principal
└── ...
```

This structure is designed for a token whose on-chain holder can receive token-level BNB rewards. Each personal vault remains the direct holder of that user's staked WATER instead of all staked WATER being merged into one address.
