---
title: Architecture
description: Modular WATER V4.4.3 staking contract architecture.
---

# Protocol Architecture

WATER staking V4.4.3 is modular so the system can keep stable user-facing addresses while separating runtime responsibilities.

```text
WATER TOKEN (non-upgradeable)
        │
        ▼
STABLE ERC1967 / UUPS CONTROLLER PROXY
        │
        ├── WaterStakingLens (read-only views)
        ├── WaterStakingVaultFactory (personal vault deployment)
        ├── WaterStakingAdapterRegistry (approved BNB→WATER adapters)
        └── UpgradeableBeacon
                │
                ├── BeaconProxy vault A
                ├── BeaconProxy vault B
                └── BeaconProxy vault ...
```

## Responsibility split

- **Controller:** reward accounting, schedules, staking actions, lock synchronization, penalties and protocol controls.
- **Lens:** read-only current account/reward/status views.
- **Factory:** creates/reuses personal vaults.
- **Beacon + vault implementation:** shared upgradeable logic behind stable personal vault addresses.
- **Adapter registry:** governance-controlled approval of BNB → WATER adapter contracts.
