---
title: Locked Lifecycle
description: Deposit, expiry, rollover, re-lock and early-exit behavior of the 30-day position.
---

# Locked Lifecycle

## Direct Locked deposit

A new direct wallet deposit into Locked creates or increases the Locked principal and establishes a 30-day unlock timestamp.

## Fresh Locked top-up

Fresh WATER added to an active Locked position restarts the Locked period for the resulting Locked position.

## Reward compounding into Locked

Compounding earned WATER into Locked adds reward principal to the existing Locked position without being treated as a fresh wallet top-up that silently moves Flexible funds.

## Expiry

After the timestamp expires, synchronization rolls expired Locked principal into Flexible.

## Voluntary early exit

Before expiry, the dedicated emergency Locked exit path is available with its penalty and forfeited Locked-reward behavior.
