---
title: Reward Pools & Accounting
description: Flexible and Locked WATER reward budgets, rates, liabilities and reserve solvency.
---

# Reward Pools & Accounting

The controller has two staking reward pools:

- Pool `0` — Flexible
- Pool `1` — Locked

Each pool tracks:

- reward period finish;
- last update time;
- reward rate;
- reward-per-token accumulator;
- total active stake;
- funded budget; and
- accrued liability.

## Funding and scheduling

`fundRewards(poolId, amount)` transfers funded WATER into the controller and increases the selected pool budget. `scheduleRewards(poolId, duration)` establishes the emission schedule for that pool.

## Reserve solvency

The controller exposes `rewardReserveRequired()` and `rewardReserveSolvent()` so the application can verify that the controller WATER balance covers the funded reward reserve.

The dApp's current readiness logic also validates the same invariant from the controller balance and pool budgets so a failed convenience read cannot falsely report insolvency when the underlying state is solvent.
