---
title: Governance & Upgradeability
description: Owner/operator separation and upgrade boundaries in WATER staking.
---

# Governance & Upgradeability

## Owner

The controller owner controls governance-sensitive actions such as controller upgrades, ownership changes, reward funding/recovery controls and other high-authority settings. The vault beacon has its own ownership and upgrade path for shared vault implementation changes.

## Operator

The operator is intended for maintenance and synchronization operations. It is not a second owner and is not intended to gain ownership of user vaults or redirect user principal/BNB.

## Stable addresses

The controller is accessed through a stable UUPS/ERC1967 proxy. Personal vaults use stable BeaconProxy addresses. Logic can therefore be upgraded without changing those user-facing addresses.
