---
title: BNB → WATER Adapter
description: Controlled adapter architecture for compounding personal-vault BNB into WATER.
---

# BNB → WATER Adapter

BNB compounding is isolated behind an approved adapter architecture.

```text
Personal vault BNB
      ↓
Approved adapter
      ↓
Pancake-compatible BNB/WATER swap
      ↓
WATER returned
      ↓
Flexible or Locked destination
```

The vault's `compoundBNB` call takes the BNB amount, adapter, minimum WATER output, deadline and destination pool.

The adapter registry controls which adapter addresses are approved. This prevents an ordinary maintenance operator from arbitrarily replacing the swap path.
