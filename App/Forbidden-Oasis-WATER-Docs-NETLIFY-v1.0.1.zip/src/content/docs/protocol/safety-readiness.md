---
title: Safety & Mainnet Readiness
description: Production staking gate, reserve solvency and token/controller configuration checks.
---

# Safety & Mainnet Readiness

The production dApp does not treat "contracts deployed" as sufficient for public staking. Mainnet staking is gated by a readiness report.

Typical readiness conditions include:

- WATER points to the correct staking controller;
- required token/controller exemptions are correct;
- controller and related deployment addresses are configured;
- reward pools are funded and scheduled;
- required staking features are enabled;
- staking is not paused or under protocol emergency shutdown; and
- reward reserve solvency passes.

## Redundant reserve verification

The current v3.5.6 app inherited the v3.5.5 readiness fix: reserve solvency can be confirmed from the direct `rewardReserveSolvent()` read **or** from the underlying controller WATER balance versus `rewardReserveRequired()` / pool budgets. This prevents one failed RPC read from incorrectly turning a solvent live deployment into a false "FAILED" state.
