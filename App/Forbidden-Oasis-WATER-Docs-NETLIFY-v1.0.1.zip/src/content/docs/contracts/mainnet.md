---
title: Mainnet Deployments
description: Live BSC Mainnet contracts used by the current WATER staking dApp.
---

# Mainnet Deployments

These are the BSC Mainnet addresses embedded as the production defaults in the current v3.5.6 staking app configuration.

| Contract | Address |
| --- | --- |
| WATER token | [`0xE26505E856fB1Ee6Ad85D433E2Ac3C3516C676a5`](https://bscscan.com/address/0xE26505E856fB1Ee6Ad85D433E2Ac3C3516C676a5) |
| Controller proxy | [`0xCe0A13E5AC12E79C6eBecab7eBB891547B0db8F5`](https://bscscan.com/address/0xCe0A13E5AC12E79C6eBecab7eBB891547B0db8F5) |
| Controller implementation | [`0x88285C85fc7744C27AF579A37f30D6f8AbdF9c71`](https://bscscan.com/address/0x88285C85fc7744C27AF579A37f30D6f8AbdF9c71) |
| Staking Lens | [`0x1a47aa6B4E2eb65aED731E2DF11D8B8f883BbBAa`](https://bscscan.com/address/0x1a47aa6B4E2eb65aED731E2DF11D8B8f883BbBAa) |
| Vault factory | [`0x5AA38c5a9F90A1ED42114f403901E0246C0613a0`](https://bscscan.com/address/0x5AA38c5a9F90A1ED42114f403901E0246C0613a0) |
| Adapter registry | [`0x90C368868ed845d55AA6eFdED5b8B90A6c82C2Bb`](https://bscscan.com/address/0x90C368868ed845d55AA6eFdED5b8B90A6c82C2Bb) |
| Vault beacon | [`0x0D3602014fa09E969D68697eCaD6fbB76df961Fb`](https://bscscan.com/address/0x0D3602014fa09E969D68697eCaD6fbB76df961Fb) |
| Vault implementation | [`0x55D1734590CE927d6a30f3b67a6b61b7264F2a6a`](https://bscscan.com/address/0x55D1734590CE927d6a30f3b67a6b61b7264F2a6a) |
| BNB → WATER adapter | [`0x655b4F69f2c204ed248Ff8110C0AC7eeDeD58ab4`](https://bscscan.com/address/0x655b4F69f2c204ed248Ff8110C0AC7eeDeD58ab4) |
| Pancake V2 router | [`0x10ED43C718714eb63d5aA57B78B54704E256024E`](https://bscscan.com/address/0x10ED43C718714eb63d5aA57B78B54704E256024E) |
| Pancake V2 factory | [`0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73`](https://bscscan.com/address/0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73) |
| WBNB | [`0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c`](https://bscscan.com/address/0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c) |

The stable user-facing staking address is the **controller proxy**, not its implementation.
