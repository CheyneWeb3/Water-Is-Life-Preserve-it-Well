---
title: Lens & Vault APIs
description: Read-only account views and personal-vault user actions.
---

# Lens & Vault APIs

## WaterStakingLens

The Lens carries detailed read-only calculations out of the controller runtime.

Important reads include:

```solidity
accountView(address controller, address account)
earnedWater(address controller, address account)
currentEpoch()
unallocatedRewardBudget(address controller, uint8 poolId)
controllerWaterStatus(address controller)
```

`accountView()` returns the user's vault, lock status, Flexible/Locked principal, claimable Flexible/Locked WATER and vault BNB balance.

## Personal vault

The frontend-facing vault API includes:

```solidity
owner()
controller()
water()
pendingWaterDividends()
pullWaterDividends()
claimBNB(uint256)
compoundBNB(uint256,address,uint256,uint256,uint8)
emergencyExitWater()
```
