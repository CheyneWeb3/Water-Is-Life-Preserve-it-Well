---
title: WATER Token API
description: WATER token functions relevant to staking integration and token administration.
---

# WATER Token API

The dApp reads standard ERC-20 state plus WATER-specific dividend and owner configuration.

## Staking integration

```solidity
stakingController() view returns (address)
setStakingController(address controller)
```

## Limits and exemptions

```solidity
maxWalletAmount()
maxBuyAmount()
limitsEnabled()
setMaxWalletAmount(uint256)
setMaxBuyAmount(uint256)
removeLimits()
excludeFromFees(address,bool)
excludeFromLimits(address,bool)
excludeFromDividends(address,bool)
```

## Dividends

```solidity
pendingBNBRewards(address)
claimDividends()
isReflectionEligible(address)
holdTimeRemaining(address)
```

## Supply / burn

```solidity
totalSupply()
totalTokensBurned()
manualBurn(uint256)
```

Token-owner functions remain governed by WATER's own ownership rules, independently from staking-controller operator permissions.
