---
title: Controller API
description: Frontend-facing WaterStakingController V4.4.3 function surface.
---

# Controller API

The dApp intentionally uses a compact ABI surface matching the canonical V4.4.3 controller.

## Key reads

```solidity
owner()
operator()
implementationVersion()
paused()
emergencyShutdown()
flexibleStakingEnabled()
lockedStakingEnabled()
relockEnabled()
waterCompoundingEnabled()
bnbCompoundingEnabled()
totalStakedWater()
vaultOf(address)
rewardPools(uint8)
rewardReserveRequired()
rewardReserveSolvent()
```

## User writes

```solidity
createVault()
stakeFlexible(uint256)
stakeLocked(uint256)
relock(uint256)
withdraw(uint256)
emergencyWithdrawLocked()
claimWater(uint256)
compoundWater(uint256,uint8)
syncPosition(address)
```

## Operational / governance writes

```solidity
fundRewards(uint8,uint256)
scheduleRewards(uint8,uint64)
setFeatureEnabled(uint8,bool)
pauseStaking()
unpauseStaking()
activateEmergencyShutdown()
setOperator(address)
runMaintenance(address[])
recoverExcessControllerWater(address,uint256)
upgradeTo(address)
transferOwnership(address)
```

On-chain role checks determine who can execute privileged functions.
