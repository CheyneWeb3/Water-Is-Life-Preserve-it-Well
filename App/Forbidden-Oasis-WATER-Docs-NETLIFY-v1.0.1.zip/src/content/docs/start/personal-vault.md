---
title: Your Personal Vault
description: Why every WATER staker receives a permanent personal on-chain vault.
---

# Your Personal Vault

The personal vault is the core design choice behind WATER staking.

Traditional staking often transfers all users' tokens to one shared staking contract. WATER is a dividend-paying token, so that shared-custody model would also concentrate on-chain token ownership and potentially redirect token-level BNB dividend behavior.

WATER staking instead creates **one permanent vault per user**.

```text
YOUR WALLET
    │
    └── stake WATER
            │
            ▼
YOUR PERSONAL VAULT
    ├── Flexible principal
    ├── Locked principal
    ├── WATER staking reward entitlement
    └── eligible vault BNB
```

The vault is created once and reused, even if it later becomes empty. Its address remains stable while shared vault logic can evolve through the protocol's upgradeable beacon architecture.
