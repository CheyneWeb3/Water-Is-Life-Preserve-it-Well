---
title: Quick Start
description: Connect to BSC Mainnet, create your personal WATER vault and choose Flexible or Locked staking.
---

# Quick Start

WATER staking is live on **BNB Smart Chain Mainnet (Chain ID 56)**.

## 1. Connect your wallet

Open the Forbidden Oasis staking dApp and connect the wallet that holds your WATER. The production app exposes **BSC Mainnet only** through Reown AppKit.

## 2. Create your personal vault

On first use, create your personal vault. Vault creation does **not** stake or move WATER by itself. It creates the permanent on-chain vault used by your account.

## 3. Choose a staking position

| Position | Principal | Lock | Normal withdrawal |
| --- | --- | --- | --- |
| **Flexible** | Separate Flexible balance | No fixed lock | Yes |
| **Locked** | Separate Locked balance | Fixed 30 days | After expiry, or voluntary early-exit path |

You can hold both positions at the same time. Adding WATER to Locked does not automatically move your existing Flexible principal.

## 4. Approve, then stake

If the controller does not already have sufficient ERC-20 allowance, your wallet will first request a WATER approval transaction. The staking transaction follows after approval.

## 5. Manage rewards from My Vault

The vault workspace gives you the main reward and principal actions:

- Claim WATER
- Pull pending WATER dividends into the vault
- Claim vault-held BNB
- Compound WATER
- Compound BNB → WATER
- Withdraw Flexible
- Re-lock selected Flexible WATER into Locked
- Use the voluntary Locked emergency exit when required

See [Staking Overview](/staking/overview/) for the complete user flow.
