---
title: Wallet & BSC Mainnet
description: Production network and wallet behavior for WATER staking.
---

# Wallet & BSC Mainnet

The production staking app is intentionally pinned to **BNB Smart Chain Mainnet (Chain ID 56)**.

## Reown AppKit

The current app uses Reown AppKit with the Wagmi adapter. The production network list contains BSC Mainnet only, and the app's supported-chain guard accepts Chain 56 only.

Connection paths supported by the app include injected wallets, WalletConnect-compatible wallets, Coinbase-compatible connection paths and enabled Reown account/social flows configured for the production project.

## Wrong network

If the connected wallet is on another chain, switch it to BSC Mainnet. Production transactions are never meant to be submitted against the retained testnet configuration data.

## Before signing

Always read the wallet prompt and confirm:

- network is BNB Smart Chain;
- destination contract matches the expected WATER/controller/vault path;
- WATER amount is correct;
- BNB value is expected for the action; and
- gas settings are acceptable.
