---
title: Glossary
description: Key WATER staking and dApp terms.
---

# Glossary

**Adapter** — Approved contract used by a personal vault to convert BNB into WATER.

**Adapter Registry** — Governance-controlled registry indicating which BNB → WATER adapters are approved.

**BeaconProxy Vault** — Stable personal vault address whose shared implementation is provided through an UpgradeableBeacon.

**Controller Proxy** — Stable ERC1967/UUPS address used by the app for staking-controller interactions.

**Flexible** — Staking position without a fixed lock; normal withdrawals use Flexible principal.

**Lens** — Read-only contract used for detailed current account and protocol views.

**Locked** — Separate staking position with the current fixed 30-day lock.

**Re-lock** — Explicit movement of a selected Flexible amount into Locked.

**Reward Reserve** — WATER held by the controller to cover funded staking reward budgets/liabilities.

**Vault** — Permanent per-user contract holding the user's staked WATER and vault BNB.
