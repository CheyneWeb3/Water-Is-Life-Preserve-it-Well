---
title: FAQ
description: Common WATER staking questions.
---

# FAQ

## Can I use Flexible and Locked at the same time?

Yes. They are independent balances in the same permanent personal vault.

## Does staking Locked move my Flexible WATER?

No. Fresh Locked staking adds only the amount you explicitly selected. Re-locking Flexible is a separate explicit action.

## Why do I have a personal vault?

The vault is the direct on-chain holder of your staked WATER and is designed to preserve the distributed holder model needed for token-level BNB dividend behavior.

## Why can staking require two wallet confirmations?

ERC-20 approval may be required before the controller can transfer the chosen WATER amount. Approval and staking are separate transactions.

## Why does Claim BNB sometimes require Pull Into Vault first?

Eligible token-level dividends can still be pending. Pulling collects them into the personal vault; Claim BNB then sends vault-held BNB to the owner.

## Why can Compound All require two transactions?

WATER compounding and BNB compounding use different contract paths. The current contracts do not expose one atomic "compound everything" call.

## Is the production dApp on Testnet?

No. The v3.5.6 production UI exposes BSC Mainnet only.
