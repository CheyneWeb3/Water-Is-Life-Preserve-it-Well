---
title: Version & Scope
description: Documentation baseline and source scope.
---

# Version & Scope

This docs package was created against:

| Component | Baseline |
| --- | --- |
| Staking dApp | `v3.5.6` Mainnet-only Reown build |
| Staking protocol integration | `V4.4.3` |
| Production network | BNB Smart Chain Mainnet (`56`) |
| Starlight | `0.41.4` |
| Astro | `7.1.4` |

The dApp source used for this documentation includes the v3.5.5 Mainnet reserve-readiness correction and the v3.5.6 Mainnet-only Reown/network changes.

Public project source: https://github.com/CheyneWeb3/Water-Is-Life-Preserve-it-Well
