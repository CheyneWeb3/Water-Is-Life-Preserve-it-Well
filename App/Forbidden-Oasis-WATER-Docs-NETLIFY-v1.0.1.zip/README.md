# Forbidden Oasis WATER Documentation

Standalone **Astro + Starlight** documentation site for the Forbidden Oasis WATER project and staking system, prepared for direct deployment on **Netlify**.

## Public project links

- Website: https://forbidden-oasis.xyz/
- Public source: https://github.com/CheyneWeb3/Water-Is-Life-Preserve-it-Well

## Deploy on Netlify from GitHub

1. Push this folder to a GitHub repository.
2. In Netlify, choose **Add new project → Import an existing project**.
3. Select the repository.
4. Netlify reads `netlify.toml` automatically:
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Node: `22`
5. Deploy the site.
6. Add `docs.forbidden-oasis.xyz` under **Domain management** and configure the DNS record Netlify provides.

No Docker, server, Nginx, or Astro Netlify adapter is required because this site builds to static files.

## Local development

```bash
npm install
npm run dev
```

## Production test

```bash
npm run build
npm run preview
```

The generated static site is written to `dist/`.

## Baseline

- Staking dApp: v3.5.6
- Protocol integration: V4.4.3
- Production chain: BSC Mainnet / 56
